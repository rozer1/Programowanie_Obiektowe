public abstract class Wpis {
	public NrTelefoniczny telefon;
	public abstract String opis();
}
